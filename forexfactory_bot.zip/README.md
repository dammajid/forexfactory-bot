# Forex Factory Telegram Bot

Bot ini mengambil berita ekonomi penting dari Forex Factory (USD, GBP, EUR, dan hanya yang impact tinggi), lalu mengirimkannya otomatis ke channel Telegram.

### Fitur
- Ambil data dari RSS Forex Factory
- Filter: hanya berita High impact & mata uang USD, GBP, EUR
- Kirim otomatis ke channel Telegram

### Deployment
- Simpan file ini di GitHub
- Deploy sebagai Background Worker di Render

### Konfigurasi
Edit file `config.py` untuk mengisi TOKEN dan username channel Telegram Anda.
